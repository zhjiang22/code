#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;

const int MAXN=30;
const int MAXNv=1005;
int g[MAXN];
int g1[MAXN];
char a[MAXNv];
char b[MAXNv];
char c[MAXNv];
char d[MAXNv];

int main()
{
	freopen("enc.in","r",stdin);
	freopen("enc.out","w",stdout);
	gets(a);
	gets(b);
	gets(c);
	memset(g,-1,sizeof(g));
	memset(g1,-1,sizeof(g1));
	int k=strlen(a);
	for(int i=0;i<k;i++)
	{
		if(a[i]==b[i])
		{
			printf("ERROR");
			return 0;
		}
		if(g[a[i]-'a']!=-1)
		{
			printf("ERROR");
			return 0;
		}
		else	if(g1[b[i]-'a']!=-1)
		{
			printf("ERROR");
			return 0;
		}
		else
		{
			g[a[i]-'a']=(b[i]-'a');
			g1[b[i]-'a']=(a[i]-'a');
		}
	}	
	int d=strlen(c);
	for(int i=0;i<d;i++)
	{
		printf("%c",g1[c[i]-'a']+'a');
	}
	return 0;
}	
     
