#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;

const int MAXN=5005;
int g[MAXN][MAXN];
int n;

void init()
{
    char ch;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        getchar(); 
        for(int j=1;j<=n;j++)
        {
            scanf("%c",&ch);
            g[i][j]=ch-'0';
        }
    }
}

void Floyd()
{
    for(int k=1;k<=n;k++)
        for(int i=k+1;i<=n;i++)
            for(int j=i+1;j<=n;j++)
                if(g[i][k]&&g[k][j]&&g[j][i])
                    if(i!=j&&j!=k&&i!=k)
                    {
                        printf("%d %d %d\n",i,j,k);
                        exit(0);
                    }
}

int main()
{
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    init();
    Floyd();
    printf("-1\n");
    return 0;
}
     