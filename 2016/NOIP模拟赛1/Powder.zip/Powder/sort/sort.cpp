#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;

const int MAXN=100005;
int f[MAXN];
int temp;
int n;
int top;

int find(int x)
{
	int l=1,r=top;
	while(l<=r)
	{
		int mid=(l+r)/2;
		if(temp>f[mid])
			l=mid+1;
		else
			r=mid-1;
	}
	return l;
}

int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d",&n);
	f[0]=-1;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&temp);
		if(temp>f[top])
			f[++top]=temp;
		else
		{
			int x=find(temp);
			f[x]=temp;
		}
	}
	cout<<top<<endl;
}
     